let mem_size = 65536

let max_value = 65535

let max_int = 32767

let min_int = 32768

let minus_1 = max_value

let size = 16
