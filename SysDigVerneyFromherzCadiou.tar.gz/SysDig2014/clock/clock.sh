#!/bin/sh

../simulateur/./main.native ../mj/core.net | ./clock.py
