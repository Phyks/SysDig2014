let rom = ref (Array.make_matrix 512 8 false)
let addr_size = ref (0)
let word_size = ref (0)
